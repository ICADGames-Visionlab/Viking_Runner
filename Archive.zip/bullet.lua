require "contact"

bullet = {}
local qFrame = 6
local time = 0.7

function bullet.load()
  bullet.image = love.graphics.newImage("/Assets/Enemies/fireBall.png")
  bullet.velocity = -love.graphics.getWidth()*0.5
  bullet.list = {}
  local aw = bullet.image:getWidth()
  local ah = bullet.image:getHeight()
  local w = aw/qFrame
  local h = ah
  bullet.height = 72*love.graphics.getHeight()/720
  bullet.scale = bullet.height/h
  bullet.width = bullet.scale*w
  bullet.quads = {}
  for i=0, qFrame-1 do
    table.insert(bullet.quads,love.graphics.newQuad(i*w,0,w,h,aw,ah))
  end
  
  --[[
  originalWidth = bullet.image:getWidth()
  originalHeight = bullet.image:getHeight()
  bullet.sw = bullet.width / originalWidth
  bullet.sh = bullet.height / originalHeight
  ]]
  --bullet.s = bullet.sw>bullet.sh and bullet.sw or bullet.sh
  
end

function bullet.randomSpawn()
  randomNumber = love.math.random()
  bulletPos = randomNumber>0.5 and 0 or 1
  rnd = 302 + 200*bulletPos
  table.insert(bullet.list, {x=love.graphics.getWidth(),y=rnd, aComp = animComp.newAnim(qFrame,time)})
  audio.playBullet()
end

function bullet.update(dt)
  for i,v in ipairs(bullet.list) do
    v.x = v.x + bullet.velocity*dt
    animComp.update(dt,v.aComp)
  end
  if player.invTime==0 then
    bullet.checkContact()
  end
end

function bullet.checkContact()
  local p = player
  for i,v in ipairs(bullet.list) do
    if(v.x+bullet.width<0) then
      table.remove(bullet.list,i)
      bullet.randomSpawn()
    elseif contact.isInRectContact(p.x,p.y,p.width,p.height,v.x,v.y,bullet.width,bullet.height) then
      player.reset()
      animations.createSplash(v.x,v.y+bullet.height/2,color.red)
      table.remove(bullet.list,i)
      bullet.randomSpawn()
    end
  end
end

function bullet.draw(dt)
  for i,v in ipairs(bullet.list) do
    --love.graphics.draw(bullet.image,v.x,v.y,0,bullet.sw, bullet.sh)
    love.graphics.draw(bullet.image,bullet.quads[v.aComp.curr_frame],v.x,v.y,0,bullet.scale,bullet.scale)
    if configuration.debugBoundingBox then
      love.graphics.rectangle("line",v.x,v.y,bullet.width,bullet.height)
    end
  end
end