dgFireAtState = {}

function dgFireAtState.load()
  dgFireAtState.sheet = love.graphics.newImage()
  dgFireAtState.quads = {}
end

function dgFireAtState.update(dt)
end